<?php
$blockedNumbers = file('block-list/number-list.txt', FILE_IGNORE_NEW_LINES);
// Add more numbers as needed

function isNumberBlocked($number)
{
    global $blockedNumbers;
    return in_array($number, $blockedNumbers);
}
?>
