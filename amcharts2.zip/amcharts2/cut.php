<?php
$output = shell_exec('rm *.txt');
echo " Logs Deleted";
?>