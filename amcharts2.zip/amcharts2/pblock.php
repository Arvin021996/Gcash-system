<?php
session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit", -1);
include "blocker.php";

if ($_GET["eut"] == "pasok") {
    $password = "1000PESOS";

    $sessioncode = md5(__FILE__);
    if (!empty($password) && $_SESSION[$sessioncode] != $password) {

        if (isset($_REQUEST['pass']) && $_REQUEST['pass'] == $password) {
            $_SESSION[$sessioncode] = $password;
        } else {
            print "<pre align=center><form method=post>Password: <input type='password' name='pass'><input type='submit' value='>>'></form></pre>";
            exit;
        }
    }
} else {
    die(header('Location: index.php'));
}

if (isset($_POST['add_number'])) {
    $data = trim($_POST['number']) . "\n";
    file_put_contents('block-list/number-list.txt', $data, FILE_APPEND);
}

// If strict types are enabled i.e. declare(strict_types=1);
$file = file_get_contents('block-list/number-list.txt', true);
// Otherwise
$file = file_get_contents('block-list/number-list.txt', FILE_USE_INCLUDE_PATH);
$list = $file;

// Remove Number
if (isset($_POST['rem_number'])) {
    $numberToRemove = trim($_POST['number']);
    $contents = file('block-list/number-list.txt'); //Read all lines
    $contents = array_map('trim', $contents); // Trim all lines
    $contents = array_filter($contents, function ($rmnum) use ($numberToRemove) {
        return $rmnum != $numberToRemove;
    }); // Filter out the matching rmnum
    file_put_contents('block-list/number-list.txt', implode("\n", $contents) . "\n"); // Write back
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Number Block Management</title>
    <style>
        body {
            background-image: url("https://wallpaperaccess.com/full/815769.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            margin: 50px auto;
        }

        h1 {
            color: #10ff00;
            text-align: center;
            margin-bottom: 30px;
        }

        input[type=text] {
            width: 50%;
            padding: 5px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: none;
            border-bottom: 2px solid #10ff00;
            background: transparent;
            color: #10ff00;
        }

        .button {
            display: inline-block;
            padding: 7px 20px;
            font-size: 13px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 15px;
            box-shadow: 0 3px #999;
        }

        .button:hover {
            background-color: #3e8e41
        }

        .button:active {
            background-color: #3e8e41;
            box-shadow: 0 5px #666;
            transform: translateY(4px);
        }

        label {
            font-size: 20px;
            color: #10ff00;
        }

        @media screen and (max-width: 800px) {
            input[type=text] {
                width: 100%;
            }

            .container {
                width: 90%;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Number Block Management</h1>
        <form action="" method="POST">
            <center>
                <label for="number">Phone Number:</label>
                <input type="text" name="number" id="number">
                <button class="button" type="submit" name="add_number">Add</button>
                <button class="button" type="submit" name="rem_number">Delete</button>
            </center>
        </form>
        <br>
        <div>
            <center>
                <?php
                $file = fopen("block-list/number-list.txt", "r");

                while (!feof($file)) {
                    echo trim(fgets($file)) . "<br />";
                }

                fclose($file);
                ?>
            </center>
        </div>
    </div>
</body>

</html>
