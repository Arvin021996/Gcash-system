<?php


$TOKEN_BOT = "TOKEN HERE";
$userchatid = "CHAT ID HERE";

?>